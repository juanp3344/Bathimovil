﻿
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BibliotecaServicios.Entidades
{
    public class Mantenimientos
    {
        [Key]
        public int Id_Mantenimiento { get; set; }
        public DateTime Fecha_Servicio { get; set; }
        public string? Tipo_Mantenimiento { get; set; }
        public string? Descripcion_Trabajo { get; set; }
        public decimal Costo_Mano_Obra { get; set; }

        // N:1
        public int Prestamo { get; set; }
        public int Empleado { get; set; }
        public int Portatil { get; set; }

        [ForeignKey("Prestamo")] public Prestamos? _Prestamo { get; set; }
        [ForeignKey("Empleado")] public Empleados? _Empleado { get; set; }
        [ForeignKey("Portatil")] public Portatiles? _Portatil { get; set; }

        // 1:N
        [NotMapped] public List<Aseo_Elementos>? Aseo_Elementos { get; set; }

    }
}
